//
//  WebCollectionViewController.swift
//  TableView
//
//  Created by user146585 on 5/4/19.
//  Copyright © 2019 Rikke Guldberg Hansen. All rights reserved.
//


//

import UIKit
import WebKit

class WebCollectionViewController: UIViewController, WKNavigationDelegate {
    
    var cd = [Entity]()
    var webView: WKWebView!
    
    override func loadView() {
        webView = WKWebView()
        webView.navigationDelegate = self
        view = webView
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if CDHandler.fetchObject() != nil {
            cd = CDHandler.fetchObject()!
            
            // do so you go to the webpage that desccribes the category yo are in
            print(myIndexsort)
            let url = URL(string: "https://www.kk.dk/artikel/sortering-af-\(bins[myIndexsort].name ?? "https://www.kk.dk")")!
            webView.load(URLRequest(url: url))
            
            let refresh = UIBarButtonItem(barButtonSystemItem: .refresh, target: webView, action: #selector(webView.reload))
            toolbarItems = [refresh]
            navigationController?.isToolbarHidden = false
        }
    }
    
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        title = webView.title
    }
    
    
}
