//
//  MapViewController.swift
//  TableView
//
//  Created by user146585 on 3/30/19.
//  Copyright © 2019 Rikke Guldberg Hansen. All rights reserved.
//

import UIKit
import MapKit
import Foundation
import CoreLocation

class MapViewController: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate {

    let manager = CLLocationManager()
    //create function that is called every time user change location
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let location = locations[0]
        
        //this part defines how much we want to be zoomed in on the users locations
        let span: MKCoordinateSpan = MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01)
        let myLocation: CLLocationCoordinate2D = CLLocationCoordinate2DMake(location.coordinate.latitude, location.coordinate.longitude)
        let region: MKCoordinateRegion = MKCoordinateRegion(center: myLocation, span: span)
        //display location / when running in simulator the locations will always default to san francisco
        mapView.setRegion(region, animated : true)
        //add blue dot
        self.mapView.showsUserLocation = true
    }
    
    //create connection to mapview
    @IBOutlet weak var mapView: MKMapView!
    
    //set title
    override func viewWillAppear(_ animated: Bool) {
        navigationItem.title = "Find genbrugsstation"
      //  determineMyCurrentLocation()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        mapView.delegate = self
        createAnnotations(locations:annotations) //makes annotations
        manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyBest //the desired accuracy is the best accuracy
        manager.requestWhenInUseAuthorization() //request aithorization for using the users location when in use
        manager.startUpdatingLocation() //call a function every time the location is updated
        
    }

        //create function for where to center the map. However ,we want to center the map on the user locations, therefore this is commented out
    /*
        func centerMapOnLocation(location: MKPointAnnotation, regionRadius: Double) {
            let coordinateRegion = MKCoordinateRegion(center: location.coordinate, latitudinalMeters: regionRadius * 20, longitudinalMeters: regionRadius * 20)
            mapView.setRegion(coordinateRegion, animated: true)
        }
 */
    
        
        //place pins on maps with set locations
    //place pins on maps with set locations
    func createAnnotations(locations: [annotation])  {
        for location in annotations {
            let pin = MKPointAnnotation()
            pin.title = location.title
            pin.subtitle = location.subtitle
            pin.coordinate =  CLLocationCoordinate2D(latitude: (location.latitude!), longitude: (location.longitude!))
            
            mapView.addAnnotation(pin)
            //centerMapOnLocation(location: annotation , regionRadius: 1000.0) should be used if you want to center the map around the recycling stations, however, we want hte map tp be centered around the user location
        }

            
        }

     }
   // func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
        
     //   self.performSegue(withIdentifier: "mapSegue", sender: view)
  //}



