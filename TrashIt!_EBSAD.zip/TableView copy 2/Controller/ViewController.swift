//
//  ViewController.swift
//  TableView
//
//  Created by user146585 on 3/29/19.
//  Copyright © 2019 Rikke Guldberg Hansen. All rights reserved.
//

import UIKit
import CoreData


class ViewController: UIViewController {
    
    var cd = [Entity]()
    var filePath = " "
    
    //create outlets
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var myImageView: UIImageView!
    @IBOutlet weak var descText: UITextView!
    @IBOutlet weak var binLabel: UILabel!

    
    //display labels etc from coredata (cd)
    override func viewDidLoad() {
        super.viewDidLoad()
        
        myImageView.contentMode = UIView.ContentMode.scaleAspectFill
        self.navigationController!.navigationBar.isHidden = false;
        
        
        if CDHandler.fetchObject() != nil {
            cd = CDHandler.fetchObject()!

            titleLabel.text = cd[myIndex].item
            binLabel.text = cd[myIndex].bin
            self.descText.text = load(file: cd[myIndex].bin!)
            myImageView.image = UIImage(named: cd[myIndex].bin! + ".png" )
    }
        
}
    func load(file name:String) -> String {
        if let path = Bundle.main.path(forResource: name, ofType: "txt") {
            if let contents = try? String(contentsOfFile: path, encoding: String.Encoding.utf16) {
                return contents
            } else {
                print("Fejl! - Der er ingen tekst i denne fil.")
            }
        } else {
            print("Fejl! - Denne fil eksisterer ikke.")
        }
        return ""
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        }
}
