//
//  GetDataViewController.swift
//  TableView
//
//  Created by user146585 on 4/1/19.
//  Copyright © 2019 Rikke Guldberg Hansen. All rights reserved.
//

import UIKit

class GetDataViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    
    //set title
    override func viewWillAppear(_ animated: Bool) {
        navigationItem.title = "Tilføj ting til listen"
    }
    
    //create pickerview functions
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return bins.count
    }
    func pickerView( _ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return bins[row].name
    }
    func pickerView( _ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        txtBin.text = bins[row].name
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let binPicker = UIPickerView()
        txtBin.inputView = binPicker
        binPicker.delegate = self
        
        }
    
        func textFieldShouldBeginEditing(textField: UITextField) -> Bool {
            if textField == txtTextArea {
                return false; //do not show keyboard nor cursor
        }
            return true
     }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //create buttons and textfields
    @IBOutlet weak var txtItem: UITextField!
    @IBOutlet weak var txtBin: UITextField!
    @IBOutlet weak var SaveRecord: UIButton!
    @IBOutlet weak var txtTextArea: UITextView!
    

    @IBAction func OnSaveRecord(_ sender: Any) {
        //if nothing is added show alert
        if txtItem.text == "" || txtBin.text == "" {
            let alertControllerError = UIAlertController(title: "Hov, der skete en fejl", message: "For at tilføje en ny ting til listen skal du udfylde både ‘Navn‘ og ‘Kategori‘", preferredStyle: UIAlertController.Style.alert)
            alertControllerError.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
            self.present(alertControllerError, animated: true)
        } else {
            //reference to core data
                let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
                let itemInfo = Entity(context: context)
                itemInfo.item = txtItem.text!
                itemInfo.bin = txtBin.text!
            //save the data to coredata
            (UIApplication.shared.delegate as! AppDelegate).saveContext()
            txtItem.text = nil
            txtBin.text = nil
            let alertController = UIAlertController(title: "Godt gået!", message: "Du har nu succesfuldt tilføjet en ny ting til listen", preferredStyle: UIAlertController.Style.alert)
            alertController.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
            self.present(alertController, animated: true, completion: nil)
            //txtBinDesc.text = nil
        }
    }

    }

    




