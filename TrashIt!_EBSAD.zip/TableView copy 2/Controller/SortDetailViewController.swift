//
//  SortDetailViewController.swift
//  TableView
//
//  Created by user146585 on 4/7/19.
//  Copyright © 2019 Rikke Guldberg Hansen. All rights reserved.
//

import UIKit
import CoreData

class SortDetailViewController: UIViewController {

    var cd = [Entity]()
    
    //create outlets
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var sortImage: UIImageView!
    @IBOutlet weak var sortDesc: UITextView!
    
    //fetch core data (cd)
    override func viewDidLoad() {
        super.viewDidLoad()
        
        sortImage.contentMode = UIView.ContentMode.scaleAspectFill
        
        if CDHandler.fetchObject() != nil {
            cd = CDHandler.fetchObject()!
        titleLabel.text = bins[myIndexsort].name
        self.sortDesc.text = load(file: bins[myIndexsort].name!)
        sortImage.image = UIImage(named: bins[myIndexsort].name! + ".png" )
        }
        
    }
    func load(file name:String) -> String {
        if let path = Bundle.main.path(forResource: name, ofType: "txt") {
            if let contents = try? String(contentsOfFile: path, encoding: String.Encoding.utf16) {
                return contents
            } else {
                print("Fejl! - Der er ingen tekst i denne fil.")
            }
        } else {
            print("Fejl! - Denne fil eksisterer ikke.")
        }
        return ""
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}

