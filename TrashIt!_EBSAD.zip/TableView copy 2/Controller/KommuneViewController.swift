//
//  KommuneViewController.swift
//  TableView
//
//  Created by user146585 on 5/5/19.
//  Copyright © 2019 Rikke Guldberg Hansen. All rights reserved.
//

import UIKit

class KommuneViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    
    @IBOutlet weak var picker: UIPickerView!
    
    override func viewDidLoad() {
        
        self.picker.delegate = self
        self.picker.dataSource = self
        super.viewDidLoad()

    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return kommuner.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return kommuner[row].name
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        performSegue(withIdentifier: "KBHSegue", sender: self)

    }
    }


