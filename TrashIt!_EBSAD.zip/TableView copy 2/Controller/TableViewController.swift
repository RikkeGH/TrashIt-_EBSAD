//
//  TableViewController.swift
//  TableView
//
//  Created by user146585 on 3/29/19.
//  Copyright © 2019 Rikke Guldberg Hansen. All rights reserved.
//

import UIKit
import CoreData
import Firebase
import FirebaseDatabase


var myIndex = 0

class TableViewController: UITableViewController, UISearchResultsUpdating{
    
    
    //set variables

    var cd = [Entity]()
    var filtereditems = [Entity]()
    var resultSearchController = UISearchController()
    
    //set title
    override func viewWillAppear(_ animated: Bool) {
        navigationItem.title = "Søg på dit skrald"
        self.tableView.reloadData()
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        //make modification to fetch data from our coredatahandler
        if CDHandler.fetchObject() != nil {
            cd = CDHandler.fetchObject()!
            tableView.reloadData()
        
        }
        resultSearchController = ({
            let controller = UISearchController(searchResultsController: nil)
            controller.searchResultsUpdater = self
            controller.dimsBackgroundDuringPresentation = false
            controller.searchBar.sizeToFit()
            
            tableView.tableHeaderView = controller.searchBar
            
            return controller
        })()
        
        //reload the table
        tableView.reloadData()
    }



   override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    if (resultSearchController.isActive) {
        return filtereditems.count
    } else {
        return cd.count
    }
}
    
    //create function with what should be displayed in the tableview
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
    
        if (resultSearchController.isActive) { //iff searchcontroller is active, then show filtered items
            cell.textLabel?.text = filtereditems[indexPath.row].item
            cell.detailTextLabel?.text = filtereditems[indexPath.row].bin
            cell.imageView?.image = UIImage(named: filtereditems[indexPath.row].bin! + ".png")
            return cell
        }

        //if searchcontroller is not active ,then sho the full list / the cd (our coredata)
        else {
            cell.textLabel?.text = cd[indexPath.row].item
            cell.detailTextLabel?.text = cd[indexPath.row].bin
            cell.imageView?.image = UIImage(named: cd[indexPath.row].bin! + ".png")
            return cell
        }
    }
    
    //if someone picks a row then do this
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if (resultSearchController.isActive) {
            myIndex =  index(ofAccessibilityElement: filtereditems[indexPath.row].item!)
        
        } else {
            myIndex =  indexPath.row
        }
        performSegue(withIdentifier: "segue", sender: "cell")
        self.tableView.reloadData()
    }
    
    //function for updating the search results
    func updateSearchResults(for searchController: UISearchController) {
        filtereditems.removeAll(keepingCapacity: false)
       
        let searchTerm = searchController.searchBar.text!
        
        filtereditems = cd.filter { filtitem in
            return (filtitem.bin != nil && filtitem.bin!.lowercased().contains(searchTerm.lowercased())) ||
                (filtitem.binDesc != nil && filtitem.binDesc!.lowercased().contains(searchTerm.lowercased())) ||
                (filtitem.item != nil && filtitem.item!.lowercased().contains(searchTerm.lowercased()))
        }
        self.tableView.reloadData()
 
     }
    
    /*
    // function for deleting all core data when button is pressed
    @IBAction func deleteAll(_ sender: Any) {
 
     let appDel:AppDelegate = (UIApplication.shared.delegate as! AppDelegate)
        let context:NSManagedObjectContext = appDel.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Entity")
        fetchRequest.returnsObjectsAsFaults = false
        
        do
        {
            let results = try context.fetch(fetchRequest)
            for managedObject in results
            {
                let managedObjectData:NSManagedObject = managedObject as! NSManagedObject
                context.delete(managedObjectData)
                try context.save()
            }
        } catch let error as NSError {
            print("Deleted all my data in myEntity error : \(error) \(error.userInfo)")
        }
    }
 */
    
   
}

