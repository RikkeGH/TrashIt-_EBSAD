//
//  SortViewController.swift
//  TableView
//
//  Created by user146585 on 4/7/19.
//  Copyright © 2019 Rikke Guldberg Hansen. All rights reserved.
//

import UIKit

var myIndexsort = 0


class SortViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource{
    
    //set title
    override func viewWillAppear(_ animated: Bool) {
        navigationItem.title = "Sortering"
    }
    
    var cd = [Entity]()
   

    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var scrollView: UIScrollView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
         }
    
    //enable scroolview
    override func viewDidLayoutSubviews() {
        scrollView.isScrollEnabled = true
    }
    
    //create functions for collectionview
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return bins.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell  = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! SortCollectionViewCell
        
        
        cell.sortImage?.image = UIImage(named: bins[indexPath.row].name! + ".png")
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        myIndexsort = indexPath.row //will always be the cell the user tapped on
        performSegue(withIdentifier: "segue", sender: "cell")
    }
}


