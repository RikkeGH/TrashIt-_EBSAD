//
//  annotationData.swift
//  EBSAD
//
//  Created by user146585 on 5/6/19.
//  Copyright © 2019 Rikke Guldberg Hansen. All rights reserved.
//

import Foundation
import CoreLocation

class annotation: NSObject {
    var title: String?
    var subtitle: String?
    var latitude: CLLocationDegrees?
    var longitude:CLLocationDegrees?
}

var annotations: [annotation] =  {
    var bispeengen = annotation()
    bispeengen.title = "Bispeengen"
    bispeengen.subtitle = "Bispeengen 35, 2000 Frederiksberg"
    bispeengen.latitude = 55.695824
    bispeengen.longitude = 12.529575
    
    var borgervaenget = annotation()
    borgervaenget.title = "Borgervænget"
    borgervaenget.subtitle = "Sibeliusgade 80, 2100 København Ø"
    borgervaenget.latitude = 55.716587
    borgervaenget.longitude = 12.569863
    
    var christiania = annotation()
    christiania.title = "Christiania"
    christiania.subtitle = "Sydområdet 32, 1440 Christiania"
    christiania.latitude = 55.673879
    christiania.longitude = 12.598417
    
    var dragoer = annotation()
    dragoer.title = "Dragør"
    dragoer.subtitle = "Bachersmindevej 15, 2791 Dragør"
    dragoer.latitude = 55.582906
    dragoer.longitude = 12.626216
    
    var hvidovre = annotation()
    hvidovre.title = "Hvidovre"
    hvidovre.subtitle = "Avedøreholmen 97, 2650 Hvidovre"
    hvidovre.latitude = 55.604509
    hvidovre.longitude = 12.467681
    
    var kirstinehoej = annotation()
    kirstinehoej.title = "Kirstinehøj"
    kirstinehoej.subtitle = "Kirstinehøj 25C, 2770 Kastrup"
    kirstinehoej.latitude = 55.616433
    kirstinehoej.longitude = 12.615078
    
    var kulbanevej = annotation()
    kulbanevej.title = "Kulbanevej"
    kulbanevej.subtitle = "Retortvej 4, 2500 Valby"
    kulbanevej.latitude = 55.657857
    kulbanevej.longitude = 12.499296
    
    var vermlandsgade = annotation()
    vermlandsgade.title = "Vermlandsgade"
    vermlandsgade.subtitle = "Herjedalsgade 2-4, 2300 Københavns S"
    vermlandsgade.latitude = 55.643149
    vermlandsgade.longitude = 12.602538
    
    var vaegtergangen = annotation()
    vaegtergangen.title = "Vægtergangen"
    vaegtergangen.subtitle = "Vægtergangen 32A, 2770 Kastrup"
    vaegtergangen.latitude = 55.643149
    vaegtergangen.longitude = 12.638931
    
    var vasbygade = annotation()
    vasbygade.title = "Vasbygade"
    vasbygade.subtitle = "Vasbygade 26, 2450 København SV"
    vasbygade.latitude = 55.657169
    vasbygade.longitude = 12.551654
    
    
    return [bispeengen, borgervaenget, christiania, dragoer, hvidovre, kirstinehoej, kulbanevej, vermlandsgade, vaegtergangen, vasbygade]
}()



