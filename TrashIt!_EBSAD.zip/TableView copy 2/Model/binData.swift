//
//  binData.swift
//  EBSAD
//
//  Created by user146585 on 5/6/19.
//  Copyright © 2019 Rikke Guldberg Hansen. All rights reserved.
//

import Foundation

class bin: NSObject {
    var name: String?
}

var bins: [bin] =  {
    var bio = bin()
    bio.name = "Bioaffald"
    
    var plast = bin()
    plast.name = "Plast"
    
    var rest = bin()
    rest.name = "Restaffald"
    
    var papir = bin()
    papir.name = "Papir"
    
    var el = bin()
    el.name = "Elektronik"
    
    var stor = bin()
    stor.name = "Storskrald"
    
    var glas = bin()
    glas.name = "Glas"
    
    var have = bin()
    have.name = "Haveaffald"
    
    var metal = bin()
    metal.name = "Metal"
    
    var pap = bin()
    pap.name = "Pap"
    
    var farligt = bin()
    farligt.name = "Farligt affald"
    
    return [bio, rest, papir, el, stor, glas, have, metal, pap, farligt, plast]
}()

