//
//  cdhandler.swift
//  TableView
//
//  Created by user146585 on 4/13/19.
//  Copyri‹ght © 2019 Rikke Guldberg Hansen. All rights reserved.
//



import UIKit
import CoreData

class CDHandler: NSObject {
    
    //get context
    private class func getContext() -> NSManagedObjectContext{
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
        return appDelegate.persistentContainer.viewContext
}

    //create function to save object into core data
    class func saveObject(item: String, bin: String, binDesc: String) -> Bool {
        let context = getContext()
        let entity = NSEntityDescription.entity(forEntityName: "Entity", in: context)
        let managedObject = NSManagedObject(entity: entity!, insertInto: context)
    
        managedObject.setValue(item, forKey: "item")
        managedObject.setValue(bin, forKey: "bin")
        managedObject.setValue(binDesc, forKey: "binDesc")
    
        do {
            try context.save()
            return true
        } catch {
            return false
        }
    }

    class func fetchObject() -> [Entity]? {
        let context = getContext()
    var cd: [Entity]? = nil
    
    do {
        cd = try context.fetch(Entity.fetchRequest())
        return cd
    } catch {
        return cd
        }
    }
}
