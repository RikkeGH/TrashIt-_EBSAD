//
//  kommuneModel.swift
//  EBSAD
//
//  Created by user146585 on 5/6/19.
//  Copyright © 2019 Rikke Guldberg Hansen. All rights reserved.
//

import Foundation

class kommune: NSObject {
    var name: String?
}

var kommuner: [kommune] =  {
    var KBH = kommune()
    KBH.name = "Københavns Kommune"
    return [KBH]
}()
