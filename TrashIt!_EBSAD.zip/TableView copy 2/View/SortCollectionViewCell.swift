//
//  SortCollectionViewCell.swift
//  TableView
//
//  Created by user146585 on 4/7/19.
//  Copyright © 2019 Rikke Guldberg Hansen. All rights reserved.
//

import UIKit

class SortCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var sortImage: UIImageView!
}
    

