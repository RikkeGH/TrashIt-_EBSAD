//
//  StartScreenViewController.swift
//  TableView
//
//  Created by user146585 on 3/30/19.
//  Copyright © 2019 Rikke Guldberg Hansen. All rights reserved.
//

import UIKit

class StartScreenViewController: UIViewController {

    //create buttons and imageviews
    @IBOutlet weak var searchTrash: UIButton!
    @IBOutlet weak var searchTrashImg: UIImageView!
    @IBOutlet weak var sortTrash: UIButton!
    @IBOutlet weak var sortTrashImg: UIImageView!
    @IBOutlet weak var findLocation: UIButton!
    @IBOutlet weak var findLocationImg: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
