//
//  SortDetailViewController.swift
//  TableView
//
//  Created by user146585 on 4/6/19.
//  Copyright © 2019 Rikke Guldberg Hansen. All rights reserved.
//

import UIKit

class SortDetailViewController: UIViewController {

    @IBOutlet weak var sortImage: UIImageView!
    @IBOutlet weak var sortLabel: UILabel!
    
    @IBOutlet weak var sortDesc: UITextView!
    
    var image = UIImage()
    var name = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
       // sortDesc.text = String(descriptionArr[myIndex] )

        // Do any additional setup after loading the view.
        
        sortImage.image = image
        sortLabel.text! = name
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
